<?php
/**
 * Plugin Name: Book Manager
 * Description: A simple book management plugin with a custom post type, email notifications, a shortcode, and a customizer setting.
 * Version: 1.2
 * Author: TARUN REDDY
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}
function custom_plugin_enqueue_styles() {
    wp_enqueue_style('custom-plugin-style', plugin_dir_url(__FILE__) . 'css/custom-style.css');
}
add_action('wp_enqueue_scripts', 'custom_plugin_enqueue_styles');

// Create Custom Table on Plugin Activation
function bm_create_books_table() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'bm_books';
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $table_name (
        id BIGINT(20) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        post_id BIGINT(20) UNSIGNED NOT NULL UNIQUE,
        author VARCHAR(255) NOT NULL,
        publication_year INT(4) NOT NULL,
        FOREIGN KEY (post_id) REFERENCES {$wpdb->prefix}posts(ID) ON DELETE CASCADE
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
}
register_activation_hook(__FILE__, 'bm_create_books_table');

// Register Custom Post Type "Books"
function bm_register_books_cpt() {
    $args = array(
        'label' => __('Books', 'book-manager'),
        'public' => true,
        'supports' => ['title', 'editor', 'thumbnail'],
        'menu_icon' => 'dashicons-book',
        'has_archive' => true,
        'rewrite' => ['slug' => 'books'],
    );
    register_post_type('book', $args);
}
add_action('init', 'bm_register_books_cpt');

// Add Custom Fields (Author & Publication Year)
function bm_add_book_meta_boxes() {
    add_meta_box('bm_book_details', 'Book Details', 'bm_render_book_meta_box', 'book', 'normal', 'high');
}
add_action('add_meta_boxes', 'bm_add_book_meta_boxes');

function bm_render_book_meta_box($post) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'bm_books';

    $book = $wpdb->get_row($wpdb->prepare("SELECT author, publication_year FROM $table_name WHERE post_id = %d", $post->ID));

    $author = $book ? $book->author : '';
    $year = $book ? $book->publication_year : '';

    ?>
    <p><label>Author: <input type="text" name="bm_author" value="<?php echo esc_attr($author); ?>" /></label></p>
    <p><label>Publication Year: <input type="number" name="bm_year" value="<?php echo esc_attr($year); ?>" /></label></p>
    <?php
}

// Save Data to Custom Table
function bm_save_book_meta($post_id) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'bm_books';

    if (array_key_exists('bm_author', $_POST) && array_key_exists('bm_year', $_POST)) {
        $author = sanitize_text_field($_POST['bm_author']);
        $year = intval($_POST['bm_year']);

        $existing = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $table_name WHERE post_id = %d", $post_id));

        if ($existing) {
            $wpdb->update(
                $table_name,
                ['author' => $author, 'publication_year' => $year],
                ['post_id' => $post_id]
            );
        } else {
            $wpdb->insert(
                $table_name,
                ['post_id' => $post_id, 'author' => $author, 'publication_year' => $year]
            );
        }
    }
}
add_action('save_post_book', 'bm_save_book_meta');

// Add Theme Customizer Setting for Book Count
function bm_customize_register($wp_customize) {
    $wp_customize->add_section('bm_settings_section', array(
        'title'    => __('Book Manager Settings', 'book-manager'),
        'priority' => 30,
    ));

    $wp_customize->add_setting('bm_books_per_page', array(
        'default'           => 5,
        'sanitize_callback' => 'absint',
    ));

    $wp_customize->add_control('bm_books_per_page_control', array(
        'label'    => __('Books Per Page', 'book-manager'),
        'section'  => 'bm_settings_section',
        'settings' => 'bm_books_per_page',
        'type'     => 'number',
    ));
}
add_action('customize_register', 'bm_customize_register');

// Shortcode to Display Books with Image & Author Filter
function bm_book_list_shortcode($atts, $content = null) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'bm_books';

    ob_start();

    $authors = $wpdb->get_col("SELECT DISTINCT author FROM $table_name");
    $author_filter = isset($_GET['author']) ? sanitize_text_field($_GET['author']) : '';

    // Set the book limit: 4 for the homepage, customizer setting for other pages
    $books_per_page = is_front_page() ? 4 : get_theme_mod('bm_books_per_page', 5);

    if (!is_front_page()) {
        echo '<form method="GET" style="margin-bottom: 20px;"> 
                <label for="author">Filter by Author:</label>
                <select name="author" id="author" onchange="this.form.submit()">
                    <option value="">All Authors</option>';
        foreach ($authors as $author) {
            echo '<option value="' . esc_attr($author) . '" ' . selected($author_filter, $author, false) . '>' . esc_html($author) . '</option>';
        }
        echo '</select></form>';
    }

    $query = "SELECT b.post_id, p.post_title, p.post_excerpt, b.author, b.publication_year 
              FROM $table_name b 
              JOIN {$wpdb->prefix}posts p ON b.post_id = p.ID 
              WHERE p.post_status = 'publish'";

    if ($author_filter) {
        $query .= $wpdb->prepare(" AND b.author = %s", $author_filter);
    }

    $query .= " LIMIT " . absint($books_per_page);
    $books = $wpdb->get_results($query);

    if ($books) {
        echo '<div class="bm-books-grid" style="display: grid; grid-template-columns: repeat(auto-fill, minmax(250px, 1fr)); gap: 20px;">';
        foreach ($books as $book) {
            $book_image = get_the_post_thumbnail($book->post_id, 'medium', ['style' => 'width: 100%; height: 186px;']);
            echo '<div class="bm-book-item" style="border: 1px solid #ccc; padding: 10px;">';
            if ($book_image) {
                echo $book_image;
            } else {
                echo '<img src="' . esc_url(plugin_dir_url(__FILE__) . 'default-book.jpg') . '" alt="Default Book Image" style="width: 100%; height: 186px;">';
            }
            echo '<h4>' . esc_html($book->post_title) . '</h4>';
            echo '<div class="bm-book-meta">';
            echo '<p><strong>Author:</strong> ' . esc_html($book->author) . '</p>';
            echo '<p><strong>Year:</strong> ' . esc_html($book->publication_year) . '</p>';
            echo '</div>';
            echo '<p>' . esc_html($book->post_excerpt) . '</p>';
			
		
           echo '<div style="display: flex; justify-content: center;">
        <a href="' . get_permalink($book->post_id) . '" style="display: inline-block; padding: 10px 15px; background-color: #e95930; color: #fff; text-decoration: none; border-radius: 5px; text-align: center;">
            View Book
        </a>
      </div>';


            echo '</div>';
        }
        echo '</div>';
    } else {
        echo '<p>No books found.</p>';
    }

    return ob_get_clean();
}

add_shortcode('book_list', 'bm_book_list_shortcode');



//Email Notification

function bm_send_admin_notification($post_id) {
    if (get_post_status($post_id) !== 'publish') {
        return;
    }

    global $wpdb;
    $table_name = $wpdb->prefix . 'bm_books';

    // Delay execution slightly to ensure data is saved
    sleep(2);

    // Get book details
    $book = get_post($post_id);
    $book_title = $book->post_title;
    $book_url = get_permalink($post_id);
    $admin_email = get_option('admin_email');
    // Fetch author and year from custom table
    $book_data = $wpdb->get_row($wpdb->prepare("SELECT author, publication_year FROM $table_name WHERE post_id = %d", $post_id));

   $author = !empty($book_data->author) ? $book_data->author : 'No Author Provided';
   $year = !empty($book_data->publication_year) ? $book_data->publication_year : 'No Year Provided';

    // Debugging: Log values to check if they are retrieved
    error_log("BOOK DEBUG: Author=$author, Year=$year, Post ID=$post_id");

    // Email subject & message
    $subject = 'New Book Added: ' . $book_title;
    $message = "A new book has been added to your website:\n\n";
    $message .= "Title: $book_title\n";
    $message .= "Author: $author\n";
    $message .= "Publication Year: $year\n";
    $message .= "View Book: $book_url\n\n";
    $message .= "This is an automated notification.";

    // Send email
    wp_mail($admin_email, $subject, $message);
}

add_action('save_post_book', 'bm_send_admin_notification', 999, 1);



// Show Book Image & Author Column in Admin List
function bm_add_books_columns($columns) {
    $columns['bm_image'] = __('Book Image', 'book-manager');
    $columns['bm_author'] = __('Author', 'book-manager');
    return $columns;
}
add_filter('manage_edit-book_columns', 'bm_add_books_columns');

function bm_populate_books_columns($column, $post_id) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'bm_books';

    if ($column === 'bm_image') {
        if (has_post_thumbnail($post_id)) {
            echo get_the_post_thumbnail($post_id, 'thumbnail', ['style' => 'width: 50px; height: auto;']);
        } else {
            echo '—';
        }
    }

    if ($column === 'bm_author') {
        $author = $wpdb->get_var($wpdb->prepare("SELECT author FROM $table_name WHERE post_id = %d", $post_id));
        echo esc_html($author ? $author : '—');
    }
}
add_action('manage_book_posts_custom_column', 'bm_populate_books_columns', 10, 2);