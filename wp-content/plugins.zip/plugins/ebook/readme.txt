== Book Manager== 

A simple book management plugin with a custom post type, email notifications, and a shortcode.

== Description ==

Book Manager allows you to manage books using a custom post type. It includes email notifications when a new book is published and a shortcode for displaying books in a grid format.

== Installation ==

Download the plugin ZIP file.

Upload it to your WordPress site via the Plugins > Add New > Upload Plugin.

Activate the plugin from the Plugins menu.

== Usage ==

Add new books using the "Books" custom post type.

Fill in book details like Author and Publication Year.

Configure email notifications for new book additions.

Use the [book_list] shortcode to display books in a grid format with optional filters.

== Hooks & Filters ==

save_post_book - Triggers an email notification when a new book is published.

== Shortcodes ==

[book_list] - Displays a list of books in a grid format.

== Optional filters: ==

?author=Author Name to filter books by author.


== Changelog ==

Version 1.0 - Initial release.

== Frequently Asked Questions ==

1. How do I configure email notifications?

Email notifications are automatically sent to the site admin when a new book is published.

2. How do I display books on my site?

Use the [book_list] shortcode in any post or page. You can filter results using query parameters.

3. Can I filter books by author or year?

Yes, append ?author=Author Name to the URL where the shortcode is used.

== Support ==

For support, contact Tarun Reddy at [your email or forum link].

== License ==

This plugin is licensed under the GPL-2.0 or later license.

