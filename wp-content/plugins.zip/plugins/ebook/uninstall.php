<?php
/**
 * Uninstall script for Book Manager plugin
 */

if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit; // Exit if accessed directly
}

global $wpdb;
$table_name = $wpdb->prefix . 'bm_books';

// Delete the custom table
$wpdb->query("DROP TABLE IF EXISTS $table_name");

// Delete all posts of custom post type 'book'
$books = get_posts([
    'post_type'      => 'book',
    'numberposts'    => -1,
    'post_status'    => 'any',
]);

foreach ($books as $book) {
    wp_delete_post($book->ID, true); // Force delete
}

// Remove customizer setting
delete_option('bm_books_per_page');